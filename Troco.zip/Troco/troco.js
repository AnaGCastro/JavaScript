
function troco() {
    var valor = document.getElementById("valorPago").value - document.getElementById("valorCompra").value;
    var nota100 = 0, nota50 = 0, nota20 = 0, nota10 = 0, nota5 = 0, nota2 = 0, moeda1real = 0, moeda50 = 0, moeda25 = 0, moeda10 = 0, moeda5 = 0, moeda1 = 0;
    while (valor >= 100) {
        valor -= 100
        nota100 +=1
    }
    while (valor >= 50) {
        valor -= 50
        nota50 +=1
    }
    while (valor >= 20) {
        valor -= 20
        nota20 +=1
    }    
    while (valor >= 10) {
        valor -= 10
        nota10 +=1
    }      
    while (valor >= 5) {
        valor -= 5
        nota5 += 1
    }
    while (valor >= 2) {
        valor -= 2
        nota2 += 1
    } 
    while (valor >= 1) {
        valor -= 1
        moeda1real += 1
    }
    while (valor >= 0.5) {
        valor -= 0.5
        moeda50 += 1
    }
    while (valor >= 0.25) {
        valor -= 0.25
        moeda25 += 1
    }
    while (valor >= 0.10) {
        valor -= 0.10
        moeda10 += 1
    }
    while (valor >= 0.05) {
        valor -= 0.05
        moeda5 += 1
    }
    while (valor >= 0.01) {
        valor -= 0.01
        moeda1 += 1
    }

    while(nota100 > 0) {
        document.getElementById("cedulas").innerHTML += `
            <img src="./assets/100.jpg" alt="">
        `
        nota100--
    }
    while(nota50 > 0) {
        document.getElementById("cedulas").innerHTML += `
            <img src="./assets/50.jpg" alt="">
        `
        nota50--
    }
    while(nota20 > 0) {
        document.getElementById("cedulas").innerHTML += `
            <img src="./assets/20.jpg" alt="">
        `
        nota20--
    }
    while(nota10 > 0) {
        document.getElementById("cedulas").innerHTML += `
            <img src="./assets/10.jpg" alt="">
        `
        nota10--
    }
    while(nota5 > 0) {
        document.getElementById("cedulas").innerHTML += `
            <img src="./assets/5.jpg" alt="">
        `
        nota5--
    }
    while(nota2 > 0) {
        document.getElementById("cedulas").innerHTML += `
            <img src="./assets/2.jpg" alt="">
        `
        nota2--
    }
    while(moeda1real > 0) {
        document.getElementById("cedulas").innerHTML += `
            <img src="./assets/moeda1real.png" alt="">
        `
        moeda1real--
    }
    while(moeda50 > 0) {
        document.getElementById("cedulas").innerHTML += `
            <img src="./assets/moeda50.png" alt="">
        `
        moeda50--
    }
    while(moeda25 > 0) {
        document.getElementById("cedulas").innerHTML += `
            <img src="./assets/moeda25.png" alt="">
        `
        moeda25--
    }
    while(moeda10 > 0) {
        document.getElementById("cedulas").innerHTML += `
            <img src="./assets/moeda10.webp" alt="">
        `
        moeda10--
    }
    while(moeda5 > 0) {
        document.getElementById("cedulas").innerHTML += `
            <img src="./assets/moeda5.png" alt="">
        `
        moeda5--
    }
    while(moeda1 > 0) {
        document.getElementById("cedulas").innerHTML += `
            <img src="./assets/moeda1.png" alt="">
        `
        moeda1--
    }
}
